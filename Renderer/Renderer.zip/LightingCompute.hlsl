// Unnamed technique, shader LightingCompute
/*$(ShaderResources)*/

#define PI 3.14159265359

float3 ReconstructWorldPosition(float2 pUV, float pDepth)
{
	//screen uv to ndc
    float2 screenPos = pUV * 2.f - 1.f;
    screenPos.y = -screenPos.y;
    
	//ndc & depth -> viewSpace pos
	//view to world
    float4 world = mul(float4(screenPos, pDepth, 1.f), /*$(Variable:InvViewProjMtx)*/);
    world /= world.w;
	
    return world.xyz;
}

float3 FresnelSchlick(float cosTheta, float3 F0)
{
    return F0 + (1.f - F0) * pow(clamp(1.0 - cosTheta, 0.f, 1.f), 5.f);
}

float DistributionGGX(float3 N, float3 H, float roughness)
{
    float a = roughness * roughness;
    float a2 = a * a;
    float NdotH = max(dot(N, H), 0.f);
    float NdotH2 = NdotH * NdotH;
	
    float num = a2;
    float denom = (NdotH2 * (a2 - 1.f) + 1.f);
    denom = PI * denom * denom;
	
    return num / denom;
}

float GeometrySchlickGGX(float NdotV, float roughness)
{
    float r = (roughness + 1.0);
    float k = (r * r) / 8.0;

    float num = NdotV;
    float denom = NdotV * (1.0 - k) + k;
	
    return num / denom;
}

float GeometrySmith(float3 N, float3 V, float3 L, float roughness)
{
    float NdotV = max(dot(N, V), 0.0);
    float NdotL = max(dot(N, L), 0.0);
    float ggx2 = GeometrySchlickGGX(NdotV, roughness);
    float ggx1 = GeometrySchlickGGX(NdotL, roughness);
	
    return ggx1 * ggx2;
}

/*$(_compute:main)*/(uint3 DTid : SV_DispatchThreadID)
{
uint2 pixel = DTid.xy;

float2 uv = (float2(pixel) + .5f) / /*$(Variable:iResolution)*/.xy;

float3 position = ReconstructWorldPosition(uv, Depth[pixel]);

float occlusion = Material[pixel].r;
float roughness = Material[pixel].g;
float metallic = Material[pixel].b;

float3 N = normalize(Normal[pixel].rgb * 2.f - 1.f); //-1-1
float3 V = normalize( /*$(Variable:CameraPos)*/- position);

//direct lighting    
float3 lightPos = float3(lerp(-7.f, 7.f, abs(sin( /*$(Variable:iTime)*/))), -1.f, 0.f);
float3 Lo = float3(0.f, 0.f, 0.f);
for (int i = 0;i < 4; i++)
    {
float3 L;
float3 H;
        
float distance;
float attenuation;
float3 radiance;
        
        if (i < 3)
        {
            L = normalize(Lights[i].PosDir.xyz - position);
            H = normalize(V + L);
        
            distance = length(Lights[i].PosDir.xyz - position);
            attenuation = 1.f / (distance * distance);
            radiance = Lights[i].ColorIntensity.xyz *
attenuation;
        }
        if (i > 2)
        {
            L = normalize(lightPos - position);
            H = normalize(V + L);
        
            distance = length(lightPos - position);
            attenuation = 1.f / (distance * distance);
            radiance = /*$(Variable:LightCol)*/ * attenuation;
        }

float3 F0 = float3(.4f, .4f, .4f);
        F0 = lerp(F0, Albedo[pixel].rgb, metallic);
float3 F = FresnelSchlick(max(dot(H, V), 0.f), F0);
        
float NDF = DistributionGGX(N, H, roughness);
float G = GeometrySmith(N, V, L, roughness);

float3 numerator = NDF * G * F;
float denominator = 4.0 * max(dot(N, V), 0.f) * max(dot(N, L), 0.f) + .0001f;
float3 specular = numerator / denominator;
        
float3 kS = F;
float3 kD = float3(1.f, 1.f, 1.f) - kS;
        
        kD *= 1.f - metallic;
        
float NdotL = max(dot(N, L), 0.0);
        Lo += (kD * Albedo[pixel].rgb / PI + specular) * radiance * NdotL;
    }
    
float3 ambient = float3(.03f, .03f, .03f) * Albedo[pixel].rgb * occlusion;
float3 color = ambient + Lo;
    
    color = color / (color + float3(1.f, 1.f, 1.f));
    color = pow(color, float3(1.f / 2.2f, 1.f / 2.2f, 1.f / 2.2f));

    Output[pixel] = float4(color, 1.f);

    
}

/*
Shader Resources:
	Buffer Lights (as SRV)
	Texture Albedo (as SRV)
	Texture Normal (as SRV)
	Texture Material (as SRV)
	Texture Emissive (as SRV)
	Texture Velocity (as SRV)
	Texture Depth (as SRV)
	Texture Output (as UAV)
*/
